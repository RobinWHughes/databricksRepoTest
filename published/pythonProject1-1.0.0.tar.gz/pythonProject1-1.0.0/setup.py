from setuptools import setup

setup(
    name='pythonProject1',
    version='1.0.0',
    packages=[''],
    url='',
    license='',
    author='robin',
    author_email='',
    description=''
)
