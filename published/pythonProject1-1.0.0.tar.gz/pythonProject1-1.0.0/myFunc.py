"""
my func
"""

def ugger():
    print('ugger')